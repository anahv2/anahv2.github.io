# anahv.github.io

My personal website, where I talk about my skills, some of my projects and a personal timeline.

This is a static website built with Bootstrap, HTML, CSS and a bit of Javascript.
